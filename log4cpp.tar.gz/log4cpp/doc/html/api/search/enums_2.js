var searchData=
[
  ['syslogfacility',['SyslogFacility',['../RemoteSyslogAppender_8hh.html#a06b118819bb5c938af93b79ebaf5be1f',1,'RemoteSyslogAppender.hh']]],
  ['sysloglevel',['SyslogLevel',['../RemoteSyslogAppender_8hh.html#a07453e2636926645431e6f66b598a6d5',1,'RemoteSyslogAppender.hh']]]
];
