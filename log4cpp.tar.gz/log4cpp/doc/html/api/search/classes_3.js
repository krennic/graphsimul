var searchData=
[
  ['dailyrollingfileappender',['DailyRollingFileAppender',['../classlog4cpp_1_1DailyRollingFileAppender.html',1,'log4cpp']]],
  ['diagnosticcontext',['DiagnosticContext',['../structlog4cpp_1_1NDC_1_1DiagnosticContext.html',1,'log4cpp::NDC']]]
];
