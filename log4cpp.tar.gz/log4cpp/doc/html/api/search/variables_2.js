var searchData=
[
  ['basic_5fconversion_5fpattern',['BASIC_CONVERSION_PATTERN',['../classlog4cpp_1_1PatternLayout.html#af98de13eb4e2881975078fb869dd56e7',1,'log4cpp::PatternLayout']]]
];
