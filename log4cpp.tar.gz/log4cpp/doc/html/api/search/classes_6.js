var searchData=
[
  ['idsaappender',['IdsaAppender',['../classlog4cpp_1_1IdsaAppender.html',1,'log4cpp']]]
];
