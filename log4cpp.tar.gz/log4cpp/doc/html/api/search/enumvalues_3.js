var searchData=
[
  ['emerg',['EMERG',['../classlog4cpp_1_1Priority.html#ae1b1901a7b2bea8190b286684eecc1afa6a3724073818ca3ba3fba1392a7bd0fe',1,'log4cpp::Priority']]],
  ['error',['ERROR',['../classlog4cpp_1_1Priority.html#ae1b1901a7b2bea8190b286684eecc1afac18e3d423b0d2eaaa790344b672acc60',1,'log4cpp::Priority']]]
];
