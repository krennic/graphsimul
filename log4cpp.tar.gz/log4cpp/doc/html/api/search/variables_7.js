var searchData=
[
  ['layouts_5ffactory_5f',['layouts_factory_',['../namespacelog4cpp.html#ab459667dab75b5a3f073ad48f9944daf',1,'log4cpp']]]
];
