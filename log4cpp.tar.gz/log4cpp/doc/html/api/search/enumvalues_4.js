var searchData=
[
  ['fatal',['FATAL',['../classlog4cpp_1_1Priority.html#ae1b1901a7b2bea8190b286684eecc1afa1dae0224ebde51778073e7ba502a7510',1,'log4cpp::Priority']]]
];
