var searchData=
[
  ['warn',['warn',['../classlog4cpp_1_1Category.html#a9c372f41858234fe5ab0cfe94cfdb94a',1,'log4cpp::Category::warn(const char *stringFormat,...)'],['../classlog4cpp_1_1Category.html#a0f5bc1528f7e8947b5dc670a0f60af66',1,'log4cpp::Category::warn(const std::string &amp;message)']]],
  ['warnstream',['warnStream',['../classlog4cpp_1_1Category.html#ac283548b14f3897e20f85b83f6ce9e35',1,'log4cpp::Category']]],
  ['width',['width',['../classlog4cpp_1_1CategoryStream.html#a95f658aae4002f292b0c6b568a5a338e',1,'log4cpp::CategoryStream::width()'],['../classlog4cpp_1_1width.html#a703b38c3ba089dab576d409c50984a28',1,'log4cpp::width::width()']]],
  ['win32debugappender',['Win32DebugAppender',['../classlog4cpp_1_1Win32DebugAppender.html#ad51a4363945a344ac13c30bf5cb0e81e',1,'log4cpp::Win32DebugAppender']]]
];
