var searchData=
[
  ['base_5fvalidator_5fdata',['base_validator_data',['../classlog4cpp_1_1details_1_1base__validator__data.html',1,'log4cpp::details']]],
  ['basicconfigurator',['BasicConfigurator',['../classlog4cpp_1_1BasicConfigurator.html',1,'log4cpp']]],
  ['basiclayout',['BasicLayout',['../classlog4cpp_1_1BasicLayout.html',1,'log4cpp']]],
  ['bufferingappender',['BufferingAppender',['../classlog4cpp_1_1BufferingAppender.html',1,'log4cpp']]]
];
