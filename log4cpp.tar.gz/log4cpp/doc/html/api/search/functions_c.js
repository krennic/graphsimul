var searchData=
[
  ['ndc',['NDC',['../classlog4cpp_1_1NDC.html#a52f957aadc13895525e83868df67d135',1,'log4cpp::NDC']]],
  ['notice',['notice',['../classlog4cpp_1_1Category.html#a5a4ba8063d108e275affa4aca5aec4ef',1,'log4cpp::Category::notice(const char *stringFormat,...)'],['../classlog4cpp_1_1Category.html#acf91d597c6a676fe697060e62ae806c4',1,'log4cpp::Category::notice(const std::string &amp;message)']]],
  ['noticestream',['noticeStream',['../classlog4cpp_1_1Category.html#a6f0ece985281625a21d7d941b3683274',1,'log4cpp::Category']]],
  ['nteventlogappender',['NTEventLogAppender',['../classlog4cpp_1_1NTEventLogAppender.html#a719ea3ec43d8fc592be0ceb4c3e3454f',1,'log4cpp::NTEventLogAppender']]]
];
