var searchData=
[
  ['category',['Category',['../classlog4cpp_1_1Appender.html#a093ac9fc7a4e58af8ee55c35c8bc1c97',1,'log4cpp::Appender']]]
];
