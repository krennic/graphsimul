var searchData=
[
  ['warn',['WARN',['../classlog4cpp_1_1Priority.html#ae1b1901a7b2bea8190b286684eecc1afaa5f201ad98003369dfbcf6a7dcc9b166',1,'log4cpp::Priority']]]
];
