var searchData=
[
  ['left',['left',['../classlog4cpp_1_1CategoryStream.html#a2ae54e9301e735a12e5ccbc1bddb99eb',1,'log4cpp::CategoryStream']]],
  ['log4cppcleanup',['Log4cppCleanup',['../classlog4cpp_1_1HierarchyMaintainer.html#a59401e859f132e650de016b2c920b439',1,'log4cpp::HierarchyMaintainer']]]
];
