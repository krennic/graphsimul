var searchData=
[
  ['simple_5fconversion_5fpattern',['SIMPLE_CONVERSION_PATTERN',['../classlog4cpp_1_1PatternLayout.html#aeb2b239108ff547920ba43493346a190',1,'log4cpp::PatternLayout']]]
];
