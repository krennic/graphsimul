var searchData=
[
  ['ndc',['ndc',['../structlog4cpp_1_1LoggingEvent.html#a1d86cfec2108acc064878550b38f9d5f',1,'log4cpp::LoggingEvent']]]
];
