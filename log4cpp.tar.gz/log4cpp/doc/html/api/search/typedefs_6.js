var searchData=
[
  ['value',['Value',['../classlog4cpp_1_1Priority.html#a19c2e47a94a531d3028f7c545671ff72',1,'log4cpp::Priority']]]
];
